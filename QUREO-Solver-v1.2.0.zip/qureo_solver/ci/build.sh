#!/usr/bin/env bash
# Run from the project root. Used by GitHub Actions.
set -euo pipefail

flutter create --platforms=android --org com.qureosolver --project-name qureo_solver .

if [ -f android/app/build.gradle.kts ]; then
  app=android/app/build.gradle.kts
  root=android/build.gradle.kts
  jitpack='allprojects { repositories { maven { url = uri("https://jitpack.io") } } }'
else
  app=android/app/build.gradle
  root=android/build.gradle
  jitpack="allprojects { repositories { maven { url 'https://jitpack.io' } } }"
fi
sed -i -E 's/(applicationId[ =]+)"[^"]+"/\1"com.qureosolver.app"/' "$app"
grep -q '"com.qureosolver.app"' "$app"
sed -i 's/android:label="[^"]*"/android:label="QUREO Solver"/' android/app/src/main/AndroidManifest.xml
# The OCR engine library is hosted on JitPack.
printf '\n%s\n' "$jitpack" >> "$root"

for lang in ara eng; do
  curl --fail --silent --show-error --location --retry 3 --create-dirs \
    -o "assets/tessdata/$lang.traineddata" \
    "https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata"
done

flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build apk --debug
