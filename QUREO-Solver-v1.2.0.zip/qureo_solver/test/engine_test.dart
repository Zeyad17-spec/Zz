import 'package:flutter_test/flutter_test.dart';
import 'package:qureo_solver/core/text.dart';
import 'package:qureo_solver/engines/answer_engine.dart';
import 'package:qureo_solver/engines/code_inspector.dart';
import 'package:qureo_solver/engines/knowledge_base.dart';
import 'package:qureo_solver/engines/question_analyzer.dart';
import 'package:qureo_solver/models.dart';

const analyzer = QuestionAnalyzer();

AnswerResult solve(QuestionInput q) => const AnswerEngine().solve(q, analyzer.analyze(q));

void main() {
  test('normalization', () {
    expect(normalizeText('أَكْمِلْ  الإجابةَ؟ ١٢'), 'اكمل الاجابه 12');
  });

  test('classifies the reference example', () {
    final a = analyzer.analyze(const QuestionInput(text: 'اختر الإجابة الصحيحة: ما وظيفة المتغير في JavaScript؟'));
    expect(a.type, QuestionType.multipleChoice);
    expect(a.domain, QuestionDomain.programming);
    expect(a.language, 'JavaScript');
  });

  test('classifies types', () {
    final cases = {
      'صح أم خطأ: المصفوفة تبدأ من 0': QuestionType.trueFalse,
      'املأ الفراغ التالي': QuestionType.fillBlank,
      'صل بين المفاهيم': QuestionType.matching,
      'رتب الخطوات التالية': QuestionType.ordering,
      'ما ناتج الكود': QuestionType.codeOutput,
      'أكمل الكود التالي': QuestionType.codeCompletion,
      'اشرح الحلقات': QuestionType.longAnswer,
      'ما هي الخوارزمية': QuestionType.shortAnswer,
      'مرحبا': QuestionType.unknown,
    };
    cases.forEach((text, type) {
      expect(analyzer.analyze(QuestionInput(text: text)).type, type, reason: text);
    });
  });

  test('knowledge ids are unique and each concept finds itself', () {
    expect(knowledgeBase.map((e) => e.id).toSet().length, knowledgeBase.length);
    for (final e in knowledgeBase) {
      expect(const AnswerEngine().find(e.concept)?.id, e.id, reason: e.concept);
    }
  });

  test('chooses the only supported option', () {
    final r = solve(const QuestionInput(
      text: 'اختر الإجابة الصحيحة: ما وظيفة المتغير في JavaScript؟',
      options: ['تخزين البيانات', 'تشغيل الشاشة'],
    ));
    expect(r.status, AnswerStatus.answered);
    expect(r.answer, 'تخزين البيانات');
  });

  test('refuses negated, ambiguous or unknown questions', () {
    const negated = QuestionInput(text: 'ما ليس وظيفة المتغير؟', options: ['تخزين البيانات', 'الطباعة']);
    const ambiguous = QuestionInput(text: 'ما وظيفة المتغير؟', options: ['تخزين الأرقام', 'تخزين النصوص']);
    const unknown = QuestionInput(text: 'ما هي عاصمة المريخ؟');
    const extra = QuestionInput(text: 'ما وظيفة المتغير العام في الخيوط المتعددة؟');
    for (final q in [negated, ambiguous, unknown, extra]) {
      expect(solve(q).answer, isNull, reason: q.text);
    }
  });

  test('predicts literal output only', () {
    const ok = QuestionInput(text: 'ما ناتج الكود', code: 'console.log("hi");\nconsole.log(5)');
    const no = QuestionInput(text: 'ما ناتج الكود', code: 'console.log(x)');
    expect(solve(ok).answer, 'hi\n5');
    expect(solve(no).answer, isNull);
  });

  test('static code checks', () {
    const inspector = CodeInspector();
    expect(inspector.findIssues('if (x = 1) {}'), hasLength(1));
    expect(inspector.findIssues('for (let i = 0; i <= a.length; i++) {}'), hasLength(1));
    expect(inspector.findIssues('function f() {'), hasLength(1));
    expect(inspector.findIssues('if (x === 1) { log("("); }'), isEmpty);
    expect(inspector.findIssues('if (x >= 1) {}'), isEmpty);
  });
}
