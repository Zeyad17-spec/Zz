import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:qureo_solver/app.dart';
import 'package:qureo_solver/data/store.dart';

void main() {
  testWidgets('home is shown right to left', (tester) async {
    await tester.pumpWidget(QureoSolverApp(store: MemoryStore()));
    await tester.pumpAndSettle();
    expect(find.text('بدء التحليل'), findsOneWidget);
    expect(Directionality.of(tester.element(find.text('بدء التحليل'))), TextDirection.rtl);
  });

  testWidgets('analyze, save, then clear history', (tester) async {
    final store = MemoryStore();
    await tester.pumpWidget(QureoSolverApp(store: store));
    await tester.pumpAndSettle();
    await tester.tap(find.text('حل سؤال'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const Key('question')), 'ما هي الخوارزمية؟');
    final button = find.text('تحليل السؤال');
    await tester.ensureVisible(button);
    await tester.tap(button);
    await tester.pumpAndSettle();
    expect(await store.history(), hasLength(1));

    await tester.tap(find.text('السجل'));
    await tester.pumpAndSettle();
    expect(find.text('ما هي الخوارزمية؟'), findsWidgets);

    await tester.tap(find.text('الإعدادات'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('مسح سجل الأسئلة'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('حذف'));
    await tester.pumpAndSettle();
    expect(await store.history(), isEmpty);
  });
}
