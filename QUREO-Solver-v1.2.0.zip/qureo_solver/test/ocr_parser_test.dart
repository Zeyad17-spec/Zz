import 'package:flutter_test/flutter_test.dart';
import 'package:qureo_solver/ocr/ocr_parser.dart';

void main() {
  test('splits an Arabic question and lettered options', () {
    final d = parseOcrText('ما وظيفة المتغير؟\n\nأ) تخزين البيانات\nب) تشغيل الشاشة\n');
    expect(d.question, 'ما وظيفة المتغير؟');
    expect(d.options, ['تخزين البيانات', 'تشغيل الشاشة']);
    expect(d.code, isEmpty);
  });

  test('keeps a numbered question and separates code', () {
    final d = parseOcrText('1) What is the output?\nconsole.log(“hi”);\nA) hi\nB) error');
    expect(d.question, '1) What is the output?');
    expect(d.code, 'console.log("hi");');
    expect(d.options, ['hi', 'error']);
  });

  test('single marker line is not an option', () {
    final d = parseOcrText('اقرأ السؤال\n- ملاحظة واحدة');
    expect(d.options, isEmpty);
    expect(d.question, 'اقرأ السؤال\n- ملاحظة واحدة');
  });

  test('empty text', () {
    expect(parseOcrText(' \n‏\n').isEmpty, isTrue);
  });
}
