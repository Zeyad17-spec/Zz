/// Splits raw OCR text into question, options and code. Line order is kept.
class OcrDraft {
  const OcrDraft({this.question = '', this.options = const [], this.code = ''});
  final String question;
  final List<String> options;
  final String code;

  bool get isEmpty => question.isEmpty && options.isEmpty && code.isEmpty;
}

final _directionMarks = RegExp(r'[‎‏‪-‮⁦-⁩]');

// One pattern per marker family; group 1 is the option text.
final _markers = [
  RegExp(r'^\(?[A-Fa-f]\s*[\)\.\-:]\s+(.+)$'),
  RegExp(r'^\(?(?:هـ|[أابجدهو])\s*[\)\.\-:]\s*(.+)$'),
  RegExp(r'^\(?[1-9١-٩]\s*[\)\.\-:]\s+(.+)$'),
  RegExp(r'^[•○●◯\*\-]\s+(.+)$'),
];

final _codeLine = RegExp(
  r'^(let|const|var)\s+[A-Za-z_$]|^(function\s+\w|console\.|(if|for|while)\s*\(|else\s*\{|\})|[;{}]$',
);

OcrDraft parseOcrText(String raw) {
  final lines = raw
      .replaceAll(_directionMarks, '')
      .split('\n')
      .map((l) => l.trim())
      .where((l) => l.isNotEmpty)
      .toList();

  // Use the last run of two or more lines sharing a marker family.
  // The first line is always treated as part of the question.
  var start = -1, end = -1;
  RegExp? family;
  for (final marker in _markers) {
    var i = 1;
    while (i < lines.length) {
      var j = i;
      while (j < lines.length && marker.hasMatch(lines[j])) {
        j++;
      }
      if (j - i >= 2 && j > end) {
        start = i;
        end = j;
        family = marker;
      }
      i = j > i ? j : i + 1;
    }
  }

  final options = <String>[];
  final rest = <String>[];
  for (var i = 0; i < lines.length; i++) {
    if (family != null && i >= start && i < end) {
      options.add(family.firstMatch(lines[i])!.group(1)!.trim());
    } else {
      rest.add(lines[i]);
    }
  }

  final code = rest.where(_codeLine.hasMatch).map(_fixCode).join('\n');
  final question = rest.where((l) => !_codeLine.hasMatch(l)).join('\n');
  return OcrDraft(question: question, options: options, code: code);
}

/// Fixes only characters that are never valid in place of ASCII punctuation.
String _fixCode(String line) => line
    .replaceAll(RegExp('[“”]'), '"')
    .replaceAll(RegExp('[‘’]'), "'")
    .replaceAll('；', ';');
