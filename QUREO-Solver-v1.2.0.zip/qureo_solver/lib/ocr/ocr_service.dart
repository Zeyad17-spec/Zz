import 'dart:io';
import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:image_picker/image_picker.dart';

/// On-device image selection and text recognition.
class OcrService {
  final _picker = ImagePicker();

  Future<XFile?> pick(ImageSource source) => _picker.pickImage(source: source, maxWidth: 2000, maxHeight: 2000);

  Future<XFile?> lostImage() async => (await _picker.retrieveLostData()).file;

  /// Reads the text, then removes the temporary copy of the image.
  Future<String> read(String path, String language) async {
    try {
      return await FlutterTesseractOcr.extractText(
        path,
        language: language,
        args: {'psm': '6', 'preserve_interword_spaces': '1'},
      );
    } finally {
      try {
        await File(path).delete();
      } on FileSystemException {
        // The system cleans its cache later.
      }
    }
  }
}
