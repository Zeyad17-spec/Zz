import 'package:flutter/material.dart';
import 'app.dart';
import 'data/sqlite_store.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(QureoSolverApp(store: SqliteStore()));
}
