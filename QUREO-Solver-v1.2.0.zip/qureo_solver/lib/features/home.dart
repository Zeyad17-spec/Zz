import 'package:flutter/material.dart';
import '../data/store.dart';
import '../models.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.store, required this.onSolve});
  final Store store;
  final VoidCallback onSolve;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) => FutureBuilder<List<HistoryItem>>(
          future: store.history(),
          builder: (context, snap) {
            final items = snap.data ?? const <HistoryItem>[];
            return ListView(padding: const EdgeInsets.all(16), children: [
              const Text('مساعد تعليمي يعمل دون إنترنت لتحليل الأسئلة وفهم الحلول.'),
              const SizedBox(height: 12),
              Card(child: ListTile(title: const Text('الأسئلة المحللة'), trailing: Text('${items.length}'))),
              Card(child: ListTile(title: const Text('الأسئلة المحفوظة'), trailing: Text('${items.where((e) => e.favorite).length}'))),
              if (snap.hasError) const Text('تعذر قراءة قاعدة البيانات.'),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: onSolve, icon: const Icon(Icons.play_arrow), label: const Text('بدء التحليل')),
            ]);
          },
        ),
      );
}
