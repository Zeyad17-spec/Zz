import 'package:flutter/material.dart';
import '../engines/knowledge_base.dart';

class LessonsScreen extends StatelessWidget {
  const LessonsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final topics = knowledgeBase.map((e) => e.topic).toSet();
    return ListView(padding: const EdgeInsets.all(12), children: [
      for (final topic in topics)
        Card(
          child: ExpansionTile(title: Text(topic), children: [
            for (final e in knowledgeBase.where((e) => e.topic == topic))
              ListTile(
                title: Text(e.concept),
                subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${e.answer}\n${e.explanation}'),
                  Text(e.example, textDirection: TextDirection.ltr),
                ]),
              ),
          ]),
        ),
    ]);
  }
}
