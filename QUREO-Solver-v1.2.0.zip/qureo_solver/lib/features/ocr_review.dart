import 'package:flutter/material.dart';
import '../ocr/ocr_parser.dart';

/// Lets the user correct recognized text before it is analyzed.
class OcrReviewScreen extends StatefulWidget {
  const OcrReviewScreen({super.key, required this.draft});
  final OcrDraft draft;

  @override
  State<OcrReviewScreen> createState() => _OcrReviewState();
}

class _OcrReviewState extends State<OcrReviewScreen> {
  late final _question = TextEditingController(text: widget.draft.question);
  late final _options = TextEditingController(text: widget.draft.options.join('\n'));
  late final _code = TextEditingController(text: widget.draft.code);

  @override
  void dispose() {
    _question.dispose();
    _options.dispose();
    _code.dispose();
    super.dispose();
  }

  Widget _field(TextEditingController c, String label, {bool ltr = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: TextField(
          controller: c,
          minLines: 2,
          maxLines: 8,
          textDirection: ltr ? TextDirection.ltr : null,
          decoration: InputDecoration(labelText: label),
        ),
      );

  void _use() => Navigator.pop(
        context,
        OcrDraft(
          question: _question.text.trim(),
          options: _options.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
          code: _code.text.trim(),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('مراجعة النص المستخرج')),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('قد يخطئ التعرف على النص. راجعه وصححه قبل التحليل.'),
            const SizedBox(height: 12),
            _field(_question, 'نص السؤال'),
            _field(_options, 'الاختيارات — كل اختيار في سطر'),
            _field(_code, 'الكود البرمجي', ltr: true),
            FilledButton(onPressed: _use, child: const Text('استخدام النص')),
          ]),
        ),
      );
}
