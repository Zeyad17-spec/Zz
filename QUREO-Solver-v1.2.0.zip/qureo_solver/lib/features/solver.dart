import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../data/store.dart';
import '../engines/answer_engine.dart';
import '../engines/question_analyzer.dart';
import '../models.dart';
import '../ocr/ocr_parser.dart';
import '../ocr/ocr_service.dart';
import 'ocr_review.dart';

class SolverScreen extends StatefulWidget {
  const SolverScreen({super.key, required this.store});
  final Store store;

  @override
  State<SolverScreen> createState() => _SolverState();
}

class _SolverState extends State<SolverScreen> {
  final _question = TextEditingController();
  final _options = TextEditingController();
  final _code = TextEditingController();
  QuestionType? _manual;
  QuestionAnalysis? _analysis;
  AnswerResult? _result;
  int? _savedId;
  bool _favorite = false;
  bool _busy = false;
  bool _scanning = false;
  final _ocr = OcrService();

  @override
  void initState() {
    super.initState();
    _recoverImage();
  }

  /// Android may restart the app while the camera is open.
  Future<void> _recoverImage() async {
    try {
      final file = await _ocr.lostImage();
      if (file != null && mounted) await _scan(() async => file);
    } catch (_) {
      // Nothing to recover on this device.
    }
  }

  Future<void> _scan(Future<XFile?> Function() pick) async {
    if (_scanning) return;
    setState(() => _scanning = true);
    try {
      final file = await pick();
      if (file == null) return;
      final settings = await widget.store.settings();
      final text = await _ocr.read(file.path, settings['ocr'] ?? 'ara+eng');
      if (!mounted) return;
      final draft = parseOcrText(text);
      if (draft.isEmpty) return _message('لم يُكتشف نص. جرّب صورة أوضح.');
      final reviewed = await Navigator.of(context).push<OcrDraft>(
        MaterialPageRoute(builder: (_) => OcrReviewScreen(draft: draft)),
      );
      if (reviewed == null || !mounted) return;
      setState(() {
        _question.text = reviewed.question;
        _options.text = reviewed.options.join('\n');
        _code.text = reviewed.code;
        _manual = null;
        _result = null;
        _analysis = null;
      });
    } catch (e) {
      debugPrint('OCR failed: ${e.runtimeType}');
      if (mounted) _message('تعذر قراءة الصورة');
    } finally {
      if (mounted) setState(() => _scanning = false);
    }
  }

  @override
  void dispose() {
    _question.dispose();
    _options.dispose();
    _code.dispose();
    super.dispose();
  }

  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _run() async {
    final text = _question.text.trim();
    if (text.isEmpty) return _message('اكتب السؤال أولًا');
    final input = QuestionInput(
      text: text,
      options: _options.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
      code: _code.text.trim(),
      manualType: _manual,
    );
    final a = const QuestionAnalyzer().analyze(input);
    final r = const AnswerEngine().solve(input, a);
    setState(() {
      _analysis = a;
      _result = r;
      _savedId = null;
      _favorite = false;
      _busy = true;
    });
    try {
      final id = await widget.store.add(HistoryItem(
        question: text,
        type: a.type.label,
        domain: a.domain.label,
        status: r.status.label,
        answer: r.answer,
        explanation: r.explanation,
        createdAt: DateTime.now(),
      ));
      if (mounted) setState(() => _savedId = id);
    } catch (_) {
      if (mounted) _message('ظهرت النتيجة لكن تعذر حفظها في السجل');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleFavorite() async {
    final value = !_favorite;
    try {
      await widget.store.setFavorite(_savedId!, value);
      if (mounted) setState(() => _favorite = value);
    } catch (_) {
      if (mounted) _message('تعذر حفظ السؤال');
    }
  }

  Widget _field(TextEditingController c, String label, {Key? key, bool ltr = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          key: key,
          controller: c,
          minLines: 2,
          maxLines: 6,
          maxLength: 4000,
          textDirection: ltr ? TextDirection.ltr : null,
          decoration: InputDecoration(labelText: label, counterText: ''),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final r = _result;
    final a = _analysis;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Wrap(spacing: 8, children: [
          OutlinedButton.icon(
            onPressed: _scanning ? null : () => _scan(() => _ocr.pick(ImageSource.camera)),
            icon: const Icon(Icons.photo_camera_outlined),
            label: const Text('من الكاميرا'),
          ),
          OutlinedButton.icon(
            onPressed: _scanning ? null : () => _scan(() => _ocr.pick(ImageSource.gallery)),
            icon: const Icon(Icons.image_outlined),
            label: const Text('من المعرض'),
          ),
        ]),
        if (_scanning) const LinearProgressIndicator(),
        const SizedBox(height: 12),
        _field(_question, 'نص السؤال', key: const Key('question')),
        _field(_options, 'الاختيارات — كل اختيار في سطر', key: const Key('options')),
        _field(_code, 'الكود البرمجي (اختياري)', ltr: true),
        DropdownButton<QuestionType?>(
          isExpanded: true,
          value: _manual,
          items: [
            const DropdownMenuItem(value: null, child: Text('تحديد النوع تلقائيًا')),
            for (final t in QuestionType.values) DropdownMenuItem(value: t, child: Text(t.label)),
          ],
          onChanged: (v) => setState(() => _manual = v),
        ),
        const SizedBox(height: 10),
        FilledButton(onPressed: _busy ? null : _run, child: const Text('تحليل السؤال')),
        if (r != null && a != null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('نوع السؤال: ${a.type.label}'),
                Text('المجال: ${a.domain.label}'),
                if (a.language != null) Text('اللغة: ${a.language}'),
                const Divider(),
                Text('الحالة: ${r.status.label}', style: const TextStyle(fontWeight: FontWeight.bold)),
                if (r.answer != null) SelectableText('الإجابة: ${r.answer}'),
                Text('الشرح: ${r.explanation}'),
                for (final e in r.evidence) Text('• $e'),
                if (_savedId != null)
                  TextButton.icon(
                    onPressed: _toggleFavorite,
                    icon: Icon(_favorite ? Icons.star : Icons.star_border),
                    label: Text(_favorite ? 'محفوظ' : 'حفظ السؤال'),
                  ),
              ]),
            ),
          ),
      ]),
    );
  }
}
