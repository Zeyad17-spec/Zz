import 'package:flutter/material.dart';
import '../data/store.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.store});
  final Store store;

  Future<void> _clear(BuildContext context) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: const Text('حذف السجل بالكامل، بما فيه الأسئلة المحفوظة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('حذف')),
        ],
      ),
    );
    if (yes != true) return;
    await store.clear();
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حذف السجل')));
    }
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (context, _) => ListView(padding: const EdgeInsets.all(16), children: [
        const Text('المظهر'),
        Wrap(spacing: 8, children: [
          for (final (key, label) in const [('system', 'النظام'), ('light', 'فاتح'), ('dark', 'داكن')])
            OutlinedButton(onPressed: () => store.setSetting('theme', key), child: Text(label)),
        ]),
        const SizedBox(height: 16),
        const Text('حجم الخط'),
        Wrap(spacing: 8, children: [
          for (final (value, label) in const [('0.9', 'صغير'), ('1.0', 'عادي'), ('1.2', 'كبير')])
            OutlinedButton(onPressed: () => store.setSetting('scale', value), child: Text(label)),
        ]),
        const Divider(height: 32),
        ListTile(leading: const Icon(Icons.delete_outline), title: const Text('مسح سجل الأسئلة'), onTap: () => _clear(context)),
        const Text('لغة قراءة الصور (OCR)'),
        FutureBuilder<Map<String, String>>(
          future: store.settings(),
          builder: (context, snap) => Wrap(spacing: 8, children: [
            for (final (key, label) in const [('ara+eng', 'عربي وإنجليزي'), ('ara', 'عربي'), ('eng', 'إنجليزي')])
              ChoiceChip(
                label: Text(label),
                selected: (snap.data?['ocr'] ?? 'ara+eng') == key,
                onSelected: (_) => store.setSetting('ocr', key),
              ),
          ]),
        ),
        const ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('الخصوصية'), subtitle: Text('الأسئلة تُحفظ على جهازك، وقراءة الصور تتم محليًا. التطبيق لا يرسلها ولا يطلب بيانات دخول QUREO.')),
        ListTile(leading: const Icon(Icons.info_outline), title: const Text('التراخيص والمكتبات'), onTap: () => showLicensePage(context: context, applicationName: 'QUREO Solver', applicationVersion: '1.2.0')),
        const ListTile(title: Text('الإصدار 1.2.0'), subtitle: Text('تطبيق مستقل غير تابع لمنصة QUREO.')),
      ]),
      );
}
