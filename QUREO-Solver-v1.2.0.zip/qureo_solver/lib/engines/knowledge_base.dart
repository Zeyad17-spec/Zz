/// Original educational content written for this project.
class KnowledgeEntry {
  const KnowledgeEntry({
    required this.id,
    required this.topic,
    required this.concept,
    required this.answer,
    required this.explanation,
    required this.example,
    required this.triggers,
    required this.optionKeys,
  });

  final String id, topic, concept, answer, explanation, example;

  /// The whole question must be one of these phrases (after removing filler words).
  final List<String> triggers;

  /// An option is supported only if it contains one of these phrases.
  final List<String> optionKeys;

  static const source = 'محتوى أصلي لمشروع QUREO Solver';
  static const updated = '2026-11-26';
}

const knowledgeBase = <KnowledgeEntry>[
  KnowledgeEntry(
    id: 'prog-001', topic: 'أساسيات البرمجة', concept: 'ما هو البرنامج؟',
    answer: 'مجموعة تعليمات مرتبة ينفذها الحاسوب لإنجاز مهمة.',
    explanation: 'يكتب المبرمج التعليمات بلغة برمجة، ثم تُترجم أو تُفسَّر ليتمكن الجهاز من تنفيذها.',
    example: 'console.log("مرحبا");',
    triggers: ['ما هو البرنامج', 'ما المقصود بالبرنامج', 'عرف البرنامج'],
    optionKeys: ['مجموعة تعليمات', 'مجموعة من التعليمات'],
  ),
  KnowledgeEntry(
    id: 'var-001', topic: 'المتغيرات', concept: 'ما وظيفة المتغير؟',
    answer: 'تخزين قيمة تحت اسم يمكن استخدامه داخل البرنامج.',
    explanation: 'المتغير اسم يشير إلى قيمة يقرؤها البرنامج، ويمكن تغييرها بحسب طريقة تعريفه.',
    example: 'let score = 10;',
    triggers: ['ما وظيفة المتغير', 'ما هو المتغير', 'ما المقصود بالمتغير', 'عرف المتغير', 'what is a variable'],
    optionKeys: ['تخزين', 'حفظ البيانات', 'حفظ قيمة', 'store'],
  ),
  KnowledgeEntry(
    id: 'js-001', topic: 'JavaScript', concept: 'ما الكلمة المستخدمة لتعريف ثابت؟',
    answer: 'const',
    explanation: 'المتغير المعرّف بـ const لا يمكن إعادة إسناده، لكن محتوى الكائن أو المصفوفة يمكن تعديله.',
    example: 'const pi = 3.14;',
    triggers: ['تعريف ثابت', 'لتعريف ثابت', 'declare a constant'],
    optionKeys: ['const'],
  ),
  KnowledgeEntry(
    id: 'type-001', topic: 'أنواع البيانات', concept: 'ما نوع القيمتين true و false؟',
    answer: 'قيمة منطقية (Boolean).',
    explanation: 'النوع المنطقي له قيمتان فقط: true و false.',
    example: 'let done = false;',
    triggers: ['ما نوع القيمة true', 'ما نوع القيمة false', 'data type of true'],
    optionKeys: ['boolean', 'منطقية', 'منطقي'],
  ),
  KnowledgeEntry(
    id: 'op-001', topic: 'العمليات', concept: 'ما وظيفة المعامل % ؟',
    answer: 'إرجاع باقي القسمة.',
    explanation: 'يعيد المعامل % ما يتبقى بعد القسمة، ويفيد في معرفة هل العدد زوجي.',
    example: '7 % 2 // 1',
    triggers: ['وظيفة المعامل %', 'ماذا يفعل المعامل %'],
    optionKeys: ['باقي القسمة', 'remainder'],
  ),
  KnowledgeEntry(
    id: 'op-002', topic: 'العمليات', concept: 'ما وظيفة المعامل === ؟',
    answer: 'مقارنة القيمة والنوع معًا.',
    explanation: 'على عكس == لا يحوّل المعامل === الأنواع قبل المقارنة.',
    example: '5 === "5" // false',
    triggers: ['وظيفة المعامل ===', 'ماذا يفعل المعامل ==='],
    optionKeys: ['القيمة والنوع', 'value and type'],
  ),
  KnowledgeEntry(
    id: 'cond-001', topic: 'الشروط', concept: 'ما وظيفة جملة if؟',
    answer: 'تنفيذ جزء من الكود عند تحقق شرط.',
    explanation: 'إذا كانت نتيجة الشرط صحيحة نُفّذت الكتلة، وإلا تُخطّيت أو نُفّذت كتلة else.',
    example: 'if (x > 0) { console.log("موجب"); }',
    triggers: ['ما وظيفة جملة if', 'ما وظيفة if', 'what does if do'],
    optionKeys: ['شرط', 'condition'],
  ),
  KnowledgeEntry(
    id: 'loop-001', topic: 'الحلقات', concept: 'ما وظيفة حلقة التكرار؟',
    answer: 'تكرار تنفيذ مجموعة تعليمات.',
    explanation: 'تكرر الحلقة الكتلة عددًا محددًا من المرات أو ما دام الشرط متحققًا.',
    example: 'for (let i = 0; i < 3; i++) {}',
    triggers: ['ما وظيفة حلقة التكرار', 'ما وظيفة الحلقة', 'what is a loop'],
    optionKeys: ['تكرار', 'repeat'],
  ),
  KnowledgeEntry(
    id: 'func-001', topic: 'الدوال', concept: 'ما وظيفة الدالة؟',
    answer: 'تجميع تعليمات تحت اسم لإعادة استخدامها.',
    explanation: 'تستقبل الدالة مدخلات اختيارية، وتنفذ تعليماتها عند استدعائها، وقد ترجع قيمة.',
    example: 'function add(a, b) { return a + b; }',
    triggers: ['ما وظيفة الدالة', 'ما هي الدالة', 'what is a function'],
    optionKeys: ['اعادة استخدام', 'reuse', 'reusable'],
  ),
  KnowledgeEntry(
    id: 'arr-001', topic: 'المصفوفات', concept: 'ما رقم أول عنصر في المصفوفة؟',
    answer: '0',
    explanation: 'فهرسة المصفوفات في JavaScript تبدأ من الصفر.',
    example: 'const a = ["x"]; a[0]; // "x"',
    triggers: ['رقم أول عنصر في المصفوفة', 'فهرس أول عنصر', 'index of the first element'],
    optionKeys: ['0', 'صفر', 'zero'],
  ),
  KnowledgeEntry(
    id: 'obj-001', topic: 'الكائنات', concept: 'ما هو الكائن في JavaScript؟',
    answer: 'مجموعة خصائص على شكل أزواج مفتاح وقيمة.',
    explanation: 'تجمع الكائنات بيانات مترابطة، ويمكن أن تحتوي على دوال تسمى طرقًا.',
    example: 'const user = { name: "Ali" };',
    triggers: ['ما هو الكائن', 'ما المقصود بالكائن', 'what is an object'],
    optionKeys: ['مفتاح وقيمة', 'key value', 'خصائص'],
  ),
  KnowledgeEntry(
    id: 'algo-001', topic: 'الخوارزميات', concept: 'ما هي الخوارزمية؟',
    answer: 'خطوات محددة ومرتبة لحل مشكلة.',
    explanation: 'للخوارزمية مدخلات ومخرجات وخطوات واضحة تنتهي بعد عدد محدود منها.',
    example: 'إيجاد أكبر عدد بالمرور على القائمة ومقارنة كل عنصر.',
    triggers: ['ما هي الخوارزمية', 'ما المقصود بالخوارزمية', 'عرف الخوارزمية', 'what is an algorithm'],
    optionKeys: ['خطوات', 'steps'],
  ),
  KnowledgeEntry(
    id: 'dbg-001', topic: 'تصحيح الأخطاء', concept: 'ما المقصود بتصحيح الأخطاء؟',
    answer: 'تحديد أسباب أخطاء البرنامج وإصلاحها.',
    explanation: 'يشمل إعادة إنتاج الخطأ، وتتبع القيم، وتعديل الكود، ثم التحقق من الإصلاح.',
    example: 'استخدام console.log لتتبع قيمة متغير.',
    triggers: ['ما المقصود بتصحيح الأخطاء', 'ما هو تصحيح الأخطاء', 'what is debugging'],
    optionKeys: ['اصلاحها', 'اصلاح الاخطاء', 'fix'],
  ),
];
