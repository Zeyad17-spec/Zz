enum QuestionType {
  multipleChoice('اختيار من متعدد'),
  trueFalse('صح أو خطأ'),
  fillBlank('إكمال الفراغ'),
  code('سؤال برمجي'),
  codeOutput('ناتج الكود'),
  codeDebugging('تصحيح الأخطاء'),
  codeCompletion('إكمال الكود'),
  shortAnswer('إجابة قصيرة'),
  longAnswer('إجابة مقالية'),
  matching('توصيل'),
  ordering('ترتيب'),
  unknown('غير معروف');

  const QuestionType(this.label);
  final String label;
}

enum QuestionDomain {
  programming('البرمجة'),
  mathematics('الرياضيات'),
  unknown('غير محدد');

  const QuestionDomain(this.label);
  final String label;
}

enum AnswerStatus {
  answered('مدعومة بقاعدة المعرفة'),
  needsInformation('تحتاج معلومات إضافية'),
  unsupported('غير مدعوم');

  const AnswerStatus(this.label);
  final String label;
}

class QuestionInput {
  const QuestionInput({required this.text, this.options = const [], this.code = '', this.manualType});
  final String text;
  final List<String> options;
  final String code;
  final QuestionType? manualType;
}

class QuestionAnalysis {
  const QuestionAnalysis({required this.type, required this.domain, this.language});
  final QuestionType type;
  final QuestionDomain domain;
  final String? language;
}

class AnswerResult {
  const AnswerResult({required this.status, this.answer, required this.explanation, this.evidence = const []});
  final AnswerStatus status;
  final String? answer;
  final String explanation;
  final List<String> evidence;
}

class HistoryItem {
  const HistoryItem({
    this.id,
    required this.question,
    required this.type,
    required this.domain,
    required this.status,
    this.answer,
    required this.explanation,
    required this.createdAt,
    this.favorite = false,
  });

  final int? id;
  final String question, type, domain, status, explanation;
  final String? answer;
  final DateTime createdAt;
  final bool favorite;

  HistoryItem copyWith({int? id, bool? favorite}) => HistoryItem(
        id: id ?? this.id,
        question: question,
        type: type,
        domain: domain,
        status: status,
        answer: answer,
        explanation: explanation,
        createdAt: createdAt,
        favorite: favorite ?? this.favorite,
      );

  Map<String, Object?> toMap() => {
        'question': question,
        'type': type,
        'domain': domain,
        'status': status,
        'answer': answer,
        'explanation': explanation,
        'created_at': createdAt.toIso8601String(),
        'favorite': favorite ? 1 : 0,
      };

  factory HistoryItem.fromMap(Map<String, Object?> m) => HistoryItem(
        id: m['id'] as int?,
        question: m['question'] as String,
        type: m['type'] as String,
        domain: m['domain'] as String,
        status: m['status'] as String,
        answer: m['answer'] as String?,
        explanation: m['explanation'] as String,
        createdAt: DateTime.parse(m['created_at'] as String),
        favorite: m['favorite'] == 1,
      );
}
