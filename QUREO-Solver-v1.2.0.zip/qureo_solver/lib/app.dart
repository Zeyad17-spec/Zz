import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'data/store.dart';
import 'features/shell.dart';

class QureoSolverApp extends StatefulWidget {
  const QureoSolverApp({super.key, required this.store});
  final Store store;

  @override
  State<QureoSolverApp> createState() => _AppState();
}

class _AppState extends State<QureoSolverApp> {
  ThemeMode _mode = ThemeMode.system;
  double _scale = 1;

  @override
  void initState() {
    super.initState();
    widget.store.addListener(_load);
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await widget.store.settings();
      if (!mounted) return;
      setState(() {
        _mode = ThemeMode.values.asNameMap()[s['theme']] ?? ThemeMode.system;
        _scale = double.tryParse(s['scale'] ?? '') ?? 1;
      });
    } catch (e) {
      debugPrint('Settings load failed: ${e.runtimeType}');
    }
  }

  @override
  void dispose() {
    widget.store.removeListener(_load);
    super.dispose();
  }

  ThemeData _theme(Brightness b) => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF00796B), brightness: b),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      );

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'QUREO Solver',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: _mode,
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(context).copyWith(
            textScaler: TextScaler.linear(MediaQuery.textScalerOf(context).scale(1) * _scale),
          ),
          child: child!,
        ),
        home: ShellScreen(store: widget.store),
      );
}
